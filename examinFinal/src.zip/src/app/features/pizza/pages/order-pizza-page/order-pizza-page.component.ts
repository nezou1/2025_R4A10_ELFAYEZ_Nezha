import { Component, inject } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { PizzaService, Pizza } from '../../../../services/pizza.service';

@Component({
  selector: 'app-order-pizza-page',
  standalone: true,
  imports: [FormsModule, CommonModule], // Ajout de FormsModule pour activer ngModel
  templateUrl: './order-pizza-page.component.html',
  styleUrl: './order-pizza-page.component.css',
})
export class OrderPizzaPageComponent {
  private router = inject(Router);
  private pizzaService = inject(PizzaService);

  pizzas: Pizza[] = []; // ✅ Vérification que `pizzas` est bien un tableau d'objets `Pizza`
  order = {
    pizza: '',
    size: 'Medium',
    paymentMethod: 'Cash',
    email: '',
  };

  constructor() {
    this.loadPizzas();
  }

  loadPizzas() {
    this.pizzas = this.pizzaService.getPizzas();
    console.log("Pizzas chargées :", this.pizzas); // ✅ Vérification des données dans la console
  }

  submitOrder() {
    console.log("Commande envoyée :", this.order);
    this.router.navigate(['/orders']); // Redirection après la commande
  }
}
