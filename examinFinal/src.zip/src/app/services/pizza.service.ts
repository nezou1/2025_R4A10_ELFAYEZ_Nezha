/*import { Injectable } from '@angular/core';

export interface Pizza {
  name: string;
  slug: string;
  image: string;
  description: string;
  ingredients: string[];
  price: number;
  rating: number;
}

@Injectable({
  providedIn: 'root',
})
export class PizzaService {
  private pizzas: Pizza[] = [
    { name: "Margherita", slug: "margherita", image: "", description: "", ingredients: [], price: 8.99, rating: 5 },
    { name: "Pepperoni", slug: "pepperoni", image: "", description: "", ingredients: [], price: 10.99, rating: 4 },
    { name: "Végétarienne", slug: "vegetarienne", image: "", description: "", ingredients: [], price: 9.99, rating: 3 }
  ];

  getPizzas(): Pizza[] {
    return this.pizzas;
  }
}*/
import { Injectable } from '@angular/core';

export interface Pizza {
  name: string;
  slug: string;
  image: string;
  description: string;
  ingredients: string[];
  price: number;
  rating: number;
}

@Injectable({
  providedIn: 'root',
})
export class PizzaService {
  private pizzas: Pizza[] = [
    {
      name: "Margherita",
      slug: "margherita",
      image: "https://example.com/margherita.jpg",
      description: "Une pizza classique avec sauce tomate et mozzarella.",
      ingredients: ["Tomate", "Mozzarella", "Basilic"],
      price: 8.99,
      rating: 5,
    },
    {
      name: "Pepperoni",
      slug: "pepperoni",
      image: "https://example.com/pepperoni.jpg",
      description: "Une pizza généreuse avec du pepperoni croustillant.",
      ingredients: ["Tomate", "Mozzarella", "Pepperoni"],
      price: 10.99,
      rating: 4,
    },
    {
      name: "Végétarienne",
      slug: "vegetarienne",
      image: "https://example.com/vegetarienne.jpg",
      description: "Un mélange délicieux de légumes frais et de fromage.",
      ingredients: ["Tomate", "Mozzarella", "Poivrons", "Champignons", "Oignons"],
      price: 9.99,
      rating: 3,
    }
  ];

  getPizzas(): Pizza[] {
    return this.pizzas;
  }
}
