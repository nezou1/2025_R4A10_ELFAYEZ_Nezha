import { Component, AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-slider',
  templateUrl: './slider.component.html',
  styleUrl: './slider.component.scss'
})
export class SliderComponent implements AfterViewInit {
  currentIndex: number = 0;
  testimonials: NodeListOf<Element> | undefined;
  dots: NodeListOf<Element> | undefined;

  ngAfterViewInit(): void {
    this.testimonials = document.querySelectorAll(".testimonial-card");
    this.dots = document.querySelectorAll(".dot");
    this.updateSlider(this.currentIndex);
  }

  updateSlider(index: number): void {
    this.testimonials?.forEach((card, i) => {
      card.classList.toggle("active", i === index);
    });
    this.updateDots(index);
  }

  updateDots(index: number): void {
    this.dots?.forEach((dot, i) => {
      dot.classList.toggle("active", i === index);
    });
  }

  prev(): void {
    if (this.testimonials) {
      this.currentIndex = (this.currentIndex - 1 + this.testimonials.length) % this.testimonials.length;
      this.updateSlider(this.currentIndex);
    }
  }

  next(): void {
    if (this.testimonials) {
      this.currentIndex = (this.currentIndex + 1) % this.testimonials.length;
      this.updateSlider(this.currentIndex);
    }
  }
}
